To run the assignment first open 1 terminal and
run ./receiver port rWindow

Second open another terminal and 
run ./sender hostname port window-size timeout

Choose your values for these parameters. 